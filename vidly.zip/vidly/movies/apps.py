from django.apps import AppConfig


class MoviesConfig(AppConfig):
    name = 'movies'

class ApiConfig(AppConfig):
    name='api'